﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop
{
    public partial class HomeForm : Form
    {
        DataAccess da;
        OrderService os;
        public HomeForm()
        {
            InitializeComponent();
            da = new DataAccess();
            os = new OrderService();
            DataGridView1.DataSource = os.GetOrderData();
        }

        private void HomeForm_Load(object sender, EventArgs e)
        {
            da = new DataAccess();
            string sql = "SELECT Designation FROM Employees WHERE EId='" + GlobalVariables.id + "'";
            SqlDataReader reader = da.GetData(sql);
            Employee em = new Employee();
            while (reader.Read())
            {
                em.Designation = reader["Designation"].ToString();
            }
            if (em.Designation == "Admin")
            {
                if (GlobalVariables.a <= 5 && GlobalVariables.a > 0)
                {
                    da = new DataAccess();
                    string query = "SELECT InventoryName FROM Inventories WHERE Amount='" + GlobalVariables.a + "'";
                    SqlDataReader sdr = da.GetData(query);
                    Inventory inv = new Inventory();
                    while (sdr.Read())
                    {
                        inv.InventoryName = sdr["InventoryName"].ToString();
                    }
                    string Text = inv.InventoryName + " is about to finish. There only " + GlobalVariables.a + " packets left.";

                }



                da = new DataAccess();
                string s = "SELECT SUM(Price) as Price FROM Inventories";
                SqlDataReader r = da.GetData(s);
                Inventory inventory = new Inventory();
                while (r.Read())
                {
                    inventory.Price = (int)r["Price"];
                }

                da = new DataAccess();
                string s1 = "SELECT SUM(Total) as Total FROM OrderList";
                SqlDataReader r1 = da.GetData(s1);
                Order order = new Order();
                while (r1.Read())
                {
                    order.Total = (int)r1["Total"];
                }


                EmployeesButton.Show();
                MenuButton.Show();

            }
            label1.BackColor = Color.Transparent;


        }


        private void OrderButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            orderForm of = new orderForm();
            of.Show();
        }

        private void CancelOrderButton_Click(object sender, EventArgs e)
        {
            da = new DataAccess();
            os = new OrderService();
            int result = os.DeleteOrder(oid);
            if (result == 1)
            {
                MessageBox.Show("Order Cancelled!");
                os = new OrderService();
                DataGridView1.DataSource = os.GetOrderData();
            }
        }


        private void MenuButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            menuForm mf = new menuForm();
            mf.Show();
        }


        int oid, eid, tamount;
        string ename, month;

        private void InventoryButton_Click(object sender, EventArgs e)
        {
            da = new DataAccess();
            this.Hide();
            InventoryForm i = new InventoryForm();
            i.Show();
        }

        private void EmployeesButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            employeesForm ef = new employeesForm();
            ef.Show();
        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            oid = (int)DataGridView1.Rows[e.RowIndex].Cells[0].Value;
            ename = DataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            eid = (int)DataGridView1.Rows[e.RowIndex].Cells[2].Value;
            tamount = (int)DataGridView1.Rows[e.RowIndex].Cells[3].Value;
            month = DataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
        }

        private void LogOutButton_Click(object sender, EventArgs e)
        {
            
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }

        private void HomeForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }


    }
}
