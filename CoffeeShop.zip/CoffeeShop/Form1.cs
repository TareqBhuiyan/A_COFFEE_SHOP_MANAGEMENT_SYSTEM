﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop
{
    public partial class Form1 : Form
    {
        

        public Form1()
        {
            InitializeComponent();
        }

        private void indexForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            string query = "select * from UserLogin where id = '" + this.userIdTextBox.Text + "' and password = '" + this.passwordTextBox.Text + "';";
            SqlConnection sqlcon = new SqlConnection(@"Data Source=;Initial Catalog=coffeeshopdb;");
            sqlcon.Open();
            SqlCommand sqlcom = new SqlCommand(query, sqlcon);
            SqlDataAdapter sda = new SqlDataAdapter(sqlcom);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                HomeForm h = new HomeForm();
                h.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Wrong ID or, Invalid Password!");
            }
        }



        private void indexForm_Load(object sender, EventArgs e)
        {
            label1.BackColor = Color.Transparent;
            label2.BackColor = Color.Transparent;
            label3.BackColor = Color.Transparent;
        }
    }

}



