﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShop
{
    class GlobalVariables
    {
        public static string id;
        public static int a = 0;
        public static int x , inventory;
        public static int total(int i)
        {
            a = a + i;
            return a;
        }
    }
}