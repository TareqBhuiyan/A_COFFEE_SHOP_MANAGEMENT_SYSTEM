﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop
{
     class DataAccess
     {
        SqlConnection con;
        SqlCommand command;
        public DataAccess()
        {
            this.con = new SqlConnection(@"Data Source=Desktop-jkj5gl6;Initial Catalog=coffeeshop;User ID=sa;Password=1114008090");
            this.con.Open();
        }

        public SqlDataReader GetData(string sql)
        {
            command = new SqlCommand(sql, con);
            return command.ExecuteReader();
        }

        public int Execute(string sql)
        {
            command = new SqlCommand(sql, con);
            return command.ExecuteNonQuery();
        }
    }
}
